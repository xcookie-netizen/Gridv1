import {createContext, type ReactNode, useCallback, useContext, useMemo, useState} from 'react';
import {AnimatePresence, motion} from 'framer-motion';
import {CheckCircle2, Info, TriangleAlert} from 'lucide-react';

interface ToastItem {
  id: string;
  message: string;
  tone: 'success' | 'info' | 'warning';
}

interface ToastContextValue {
  notify: (message: string, tone?: ToastItem['tone']) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

export function ToastProvider({children}: {children: ReactNode}) {
  const [items, setItems] = useState<ToastItem[]>([]);
  const notify = useCallback((message: string, tone: ToastItem['tone'] = 'success') => {
    const id = crypto.randomUUID();
    setItems((current) => [...current, {id, message, tone}]);
    window.setTimeout(() => setItems((current) => current.filter((item) => item.id !== id)), 2600);
  }, []);
  const value = useMemo(() => ({notify}), [notify]);

  return (
    <ToastContext.Provider value={value}>
      {children}
      <div className="toast-region" aria-live="polite" aria-atomic="true">
        <AnimatePresence initial={false}>
          {items.map((item) => {
            const Icon = item.tone === 'success' ? CheckCircle2 : item.tone === 'warning' ? TriangleAlert : Info;
            return (
              <motion.div
                key={item.id}
                className={`toast toast-${item.tone}`}
                initial={{opacity: 0, y: 20, scale: 0.96}}
                animate={{opacity: 1, y: 0, scale: 1}}
                exit={{opacity: 0, y: 8, scale: 0.98}}
              >
                <Icon size={18} />
                <span>{item.message}</span>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </ToastContext.Provider>
  );
}

export function useToast() {
  const context = useContext(ToastContext);
  if (!context) throw new Error('useToast must be used inside ToastProvider');
  return context;
}
