import {useEffect, useRef, useState} from 'react';

const MAX_PULL = 88;
const TRIGGER = 62;

export function usePullToRefresh(onRefresh?: () => Promise<void>) {
  const ref = useRef<HTMLDivElement>(null);
  const startY = useRef<number | null>(null);
  const active = useRef(false);
  const distanceRef = useRef(0);
  const refreshingRef = useRef(false);
  const [distance, setDistanceState] = useState(0);
  const [refreshing, setRefreshingState] = useState(false);

  const setDistance = (value: number) => {
    distanceRef.current = value;
    setDistanceState(value);
  };

  const setRefreshing = (value: boolean) => {
    refreshingRef.current = value;
    setRefreshingState(value);
  };

  useEffect(() => {
    const node = ref.current;
    if (!node || !onRefresh) return;

    const onStart = (event: TouchEvent) => {
      if (window.scrollY <= 0 && !refreshingRef.current) {
        startY.current = event.touches[0]?.clientY ?? null;
        active.current = true;
      }
    };

    const onMove = (event: TouchEvent) => {
      if (!active.current || startY.current === null || window.scrollY > 0) return;
      const delta = Math.max(0, (event.touches[0]?.clientY ?? startY.current) - startY.current);
      const eased = Math.min(MAX_PULL, delta * 0.48);
      setDistance(eased);
      if (eased > 8) event.preventDefault();
    };

    const onEnd = async () => {
      if (!active.current) return;
      active.current = false;
      startY.current = null;
      if (distanceRef.current >= TRIGGER && !refreshingRef.current) {
        setRefreshing(true);
        setDistance(46);
        try {
          await onRefresh();
        } finally {
          setRefreshing(false);
          setDistance(0);
        }
      } else {
        setDistance(0);
      }
    };

    node.addEventListener('touchstart', onStart, {passive: true});
    node.addEventListener('touchmove', onMove, {passive: false});
    node.addEventListener('touchend', onEnd, {passive: true});
    node.addEventListener('touchcancel', onEnd, {passive: true});
    return () => {
      node.removeEventListener('touchstart', onStart);
      node.removeEventListener('touchmove', onMove);
      node.removeEventListener('touchend', onEnd);
      node.removeEventListener('touchcancel', onEnd);
    };
  }, [onRefresh]);

  return {ref, distance, refreshing, armed: distance >= TRIGGER};
}
