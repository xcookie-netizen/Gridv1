export type ThemePreference = 'dark' | 'light' | 'system';
export type TimeFormatPreference = '12' | '24';

export interface GridPreferences {
  theme: ThemePreference;
  accent: string;
  haptics: boolean;
  reducedMotion: boolean;
  timeFormat: TimeFormatPreference;
}

export const defaultPreferences: GridPreferences = {
  theme: 'dark',
  accent: '#D7FF3F',
  haptics: true,
  reducedMotion: false,
  timeFormat: '24',
};

export function readPreferences(): GridPreferences {
  return {
    theme: (localStorage.getItem('grid-theme') as ThemePreference | null) ?? defaultPreferences.theme,
    accent: localStorage.getItem('grid-accent') ?? defaultPreferences.accent,
    haptics: localStorage.getItem('grid-haptics') !== 'false',
    reducedMotion: localStorage.getItem('grid-reduced-motion') === 'true',
    timeFormat: (localStorage.getItem('grid-time-format') as TimeFormatPreference | null) ?? defaultPreferences.timeFormat,
  };
}

export function resolveTheme(theme: ThemePreference): 'dark' | 'light' {
  return theme === 'system'
    ? window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'
    : theme;
}

export function applyPreferences(preferences = readPreferences()) {
  const resolved = resolveTheme(preferences.theme);
  document.documentElement.dataset.theme = resolved;
  document.documentElement.dataset.reduceMotion = preferences.reducedMotion ? 'true' : 'false';
  document.documentElement.style.setProperty('--accent', preferences.accent);
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', resolved === 'dark' ? '#08090A' : '#F2F2ED');
}

export function persistPreferences(preferences: GridPreferences) {
  localStorage.setItem('grid-theme', preferences.theme);
  localStorage.setItem('grid-accent', preferences.accent);
  localStorage.setItem('grid-haptics', String(preferences.haptics));
  localStorage.setItem('grid-reduced-motion', String(preferences.reducedMotion));
  localStorage.setItem('grid-time-format', preferences.timeFormat);
  applyPreferences(preferences);
}
