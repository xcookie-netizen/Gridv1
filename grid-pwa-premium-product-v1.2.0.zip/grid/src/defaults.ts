import {addDays,format,startOfWeek,set} from 'date-fns'; import type {GridEvent} from './types';
const classes=[
[1,'12:00','13:00','ZGEN2215 Lecture','Adams 400'],[1,'13:00','14:00','ZGEN2215 Lecture','Adams 400'],[1,'14:00','15:00','ZHSS3437 Tutorial','Lecture Theatre North 06'],
[2,'13:00','14:00','ZHSS2601 Lecture','Adams 400'],[2,'14:00','15:00','ZGEN2215 Tutorial','Seminar Room 05'],
[3,'11:00','12:00','ZHSS3437 Tutorial','Seminar Room 01'],[3,'13:00','14:30','ZBUS2302 Lecture','Lecture Theatre North 09'],
[4,'10:00','11:00','ZHSS3437 Lecture','Lecture Theatre North 06'],[4,'13:00','14:00','ZHSS2601 Lecture','Lecture Theatre North 10'],
[5,'11:30','13:00','ZBUS2302 Tutorial','Lecture Theatre North 12'],[5,'14:00','15:00','ZHSS2601 Tutorial','Seminar Room 01']
] as const;
function at(d:Date,t:string){const [h,m]=t.split(':').map(Number);return set(d,{hours:h,minutes:m,seconds:0,milliseconds:0});}
export function defaultClassEvents(weeks=26):GridEvent[]{const monday=startOfWeek(new Date(),{weekStartsOn:1});const out:GridEvent[]=[];for(let w=0;w<weeks;w++){for(const [day,s,e,title,location] of classes){const d=addDays(monday,w*7+day-1);out.push({id:`class-${w}-${day}-${s}-${title}`,title,start:at(d,s).toISOString(),end:at(d,e).toISOString(),category:'Class',location,recurrence:'weekly',colour:'#4EA463'});}}return out;}
export const quotePool=['Discipline is a decision repeated.','Win the hour in front of you.','Train with intent. Study with purpose.','Consistency compounds quietly.'];
export const todayKey=()=>format(new Date(),'yyyy-MM-dd');
