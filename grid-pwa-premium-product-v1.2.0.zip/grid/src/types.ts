export type Category='Class'|'Training'|'Study'|'Appointment'|'Personal'|'Social'|'Travel'|'WOD'|'Custom';
export interface GridEvent {id:string;title:string;start:string;end:string;category:Category;location?:string;notes?:string;colour?:string;recurrence?:'weekly'|'none';completed?:boolean;}
export interface WodMovement {id:string;name:string;details:string;}
export interface Wod {id:string;name:string;type:'For Time'|'EMOM'|'AMRAP'|'Strength'|'Chipper'|'Intervals'|'Custom';date:string;timeCap?:number;rounds?:number;rx?:string;scaled?:string;notes?:string;movements:WodMovement[];completed?:boolean;}
export interface DayNote {date:string;content:string;checklist:{id:string;text:string;done:boolean}[];pinned:boolean;updatedAt:string;}
