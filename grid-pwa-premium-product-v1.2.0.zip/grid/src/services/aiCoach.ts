export type CoachMode = 'Plan' | 'Train' | 'Study' | 'Recover';

export interface CoachContext {
  eventsToday: number;
  eventsThisWeek: number;
  nextEvent?: string;
  hasWodToday: boolean;
  note?: string;
}

export interface CoachResponse {
  title: string;
  summary: string;
  steps: string[];
  footer: string;
}

export function generateOfflineCoachResponse(question: string, mode: CoachMode, context: CoachContext): CoachResponse {
  const text = question.toLowerCase();

  if (mode === 'Train' || /wod|workout|session|leg|strength|run|crossfit/.test(text)) {
    if (/leg/.test(text)) {
      return {
        title: '45-minute lower-body session',
        summary: 'A strength-first session with enough conditioning to build capacity without compromising quality.',
        steps: [
          '8 min movement prep: bike, ankle rocks, hip airplanes and tempo squats.',
          '15 min back squat: build to 5 controlled sets of 5 at RPE 7.',
          '12 min alternating Bulgarian split squats and Romanian deadlifts.',
          '8 min bike intervals: 30 sec strong, 30 sec easy.',
          '2 min easy breathing and lower-body reset.',
        ],
        footer: 'Keep two reps in reserve and stop any movement that causes sharp pain.',
      };
    }

    return {
      title: 'Balanced engine session',
      summary: 'Even pacing, simple transitions and a clear aerobic stimulus.',
      steps: [
        '5 rounds for quality.',
        '12 calories on bike or rower.',
        '10 front squats at a sustainable load.',
        '8 pull-ups or ring rows.',
        '200 m run at controlled pace.',
      ],
      footer: 'Aim for round times within 10 seconds of each other.',
    };
  }

  if (mode === 'Study' || /study|exam|class|assignment|revision/.test(text)) {
    return {
      title: 'Protected study structure',
      summary: `${context.eventsThisWeek} fixed blocks are already on your week. Build around them instead of fighting them.`,
      steps: [
        'Place one 50-minute recall-heavy block before lunch.',
        'Add a second 50-minute block after your final class, with a 15-minute reset first.',
        'Use the final 20 minutes for retrieval practice, not rereading.',
        'Keep admin work in a separate 30-minute block.',
      ],
      footer: context.nextEvent ? `Your next fixed block is ${context.nextEvent}.` : 'Your next fixed block is not scheduled yet.',
    };
  }

  if (mode === 'Recover' || /recover|fatigue|sore|rest|sleep/.test(text)) {
    return {
      title: 'Recovery-first adjustment',
      summary: 'Reduce decision load, preserve movement quality and create a quieter evening.',
      steps: [
        'Replace hard conditioning with 25–35 minutes of easy cyclical work.',
        'Add 8 minutes of mobility for the areas that feel restricted, not painful.',
        'Eat a normal meal with carbohydrate, protein and fluids after training.',
        'Finish demanding study at least 90 minutes before sleep.',
      ],
      footer: 'Offline Grid Coach gives planning guidance, not medical assessment.',
    };
  }

  return {
    title: 'Optimised day plan',
    summary: `${context.eventsToday} scheduled blocks today. Protect the fixed work first, then place one meaningful priority in the clearest gap.`,
    steps: [
      'Choose one academic outcome and one training outcome for the day.',
      'Place the highest-focus task before your busiest cluster of events.',
      'Keep at least 30 minutes of transition time before training.',
      'Use the final 10 minutes of the day to capture tomorrow’s first action.',
    ],
    footer: context.note ? `Current focus note: ${context.note.slice(0, 90)}` : 'Add a daily focus note to make future plans more specific.',
  };
}
