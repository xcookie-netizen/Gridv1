import Dexie,{type Table} from 'dexie'; import type {GridEvent,Wod,DayNote} from './types';
class GridDB extends Dexie {events!:Table<GridEvent,string>; wods!:Table<Wod,string>; notes!:Table<DayNote,string>; constructor(){super('grid-db');this.version(1).stores({events:'id,start,end,category',wods:'id,date,type',notes:'date,updatedAt'});}}
export const db=new GridDB();
