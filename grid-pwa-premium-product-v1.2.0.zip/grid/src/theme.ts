import type {Category} from './types';

export const categoryColours: Record<Category, string> = {
  Class: '#54B36A',
  Training: '#D7FF3F',
  Study: '#6EA8FF',
  Appointment: '#FFB84D',
  Personal: '#C9A7FF',
  Social: '#FF7EAE',
  Travel: '#5BD9D1',
  WOD: '#D7FF3F',
  Custom: '#A6A6AD',
};

export const accentOptions = [
  {name: 'Electric Lime', value: '#D7FF3F'},
  {name: 'Signal Blue', value: '#70A7FF'},
  {name: 'Race Orange', value: '#FF9D3F'},
  {name: 'Pulse Pink', value: '#FF71A8'},
  {name: 'Apex Violet', value: '#A88CFF'},
  {name: 'Ice Cyan', value: '#63E6E2'},
] as const;

export const haptic = (strength: number = 8) => {
  if (localStorage.getItem('grid-haptics') === 'false') return;
  if ('vibrate' in navigator) navigator.vibrate(strength);
};
