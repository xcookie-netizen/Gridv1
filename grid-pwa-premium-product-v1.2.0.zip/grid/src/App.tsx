import type React from 'react';
import {useCallback, useEffect, useMemo, useState} from 'react';
import {NavLink, Route, Routes, useLocation, useNavigate} from 'react-router-dom';
import {
  addDays,
  addMinutes,
  differenceInMinutes,
  eachDayOfInterval,
  endOfMonth,
  endOfWeek,
  format,
  isSameDay,
  isSameMonth,
  isToday,
  parseISO,
  set,
  startOfMonth,
  startOfWeek,
  subDays,
} from 'date-fns';
import {AnimatePresence, motion, Reorder, useReducedMotion} from 'framer-motion';
import {
  Activity,
  ArrowRight,
  ArrowUpRight,
  Award,
  BarChart3,
  Bell,
  Bot,
  BookOpen,
  Brain,
  CalendarClock,
  CalendarDays,
  Check,
  CheckCircle2,
  ChevronLeft,
  ChevronRight,
  Clock,
  Copy,
  Database,
  Download,
  Dumbbell,
  Eye,
  Flame,
  Gauge,
  GraduationCap,
  GripVertical,
  HeartPulse,
  Home as HomeIcon,
  Layers3,
  ListFilter,
  Lock,
  MapPin,
  MessageSquareText,
  Moon,
  Palette,
  Pencil,
  Plus,
  RefreshCw,
  RotateCcw,
  Search,
  Send,
  Settings as SettingsIcon,
  ShieldCheck,
  SlidersHorizontal,
  Smartphone,
  Sparkles,
  Sun,
  Target,
  Timer,
  TimerReset,
  Trash2,
  TrendingUp,
  Trophy,
  Upload,
  WifiOff,
  X,
  Zap,
} from 'lucide-react';
import {db} from './db';
import {defaultClassEvents, quotePool, todayKey} from './defaults';
import {parseQuickAdd} from './parser';
import type {Category, DayNote, GridEvent, Wod, WodMovement} from './types';
import {accentOptions, categoryColours, haptic} from './theme';
import {usePullToRefresh} from './hooks/usePullToRefresh';
import {ToastProvider, useToast} from './components/Toast';
import {applyPreferences, persistPreferences, readPreferences, type GridPreferences, type ThemePreference} from './preferences';
import {generateOfflineCoachResponse, type CoachMode, type CoachResponse} from './services/aiCoach';

const uid = () => crypto.randomUUID();
const categories = Object.keys(categoryColours) as Category[];

type GridData = ReturnType<typeof useData>;
type ScheduleView = 'day' | 'week' | 'month';

function useData() {
  const [events, setEvents] = useState<GridEvent[]>([]);
  const [wods, setWods] = useState<Wod[]>([]);
  const [notes, setNotes] = useState<DayNote[]>([]);
  const [loading, setLoading] = useState(true);

  const reload = useCallback(async () => {
    const [nextEvents, nextWods, nextNotes] = await Promise.all([
      db.events.toArray(),
      db.wods.toArray(),
      db.notes.toArray(),
    ]);
    setEvents(nextEvents);
    setWods(nextWods);
    setNotes(nextNotes);
  }, []);

  useEffect(() => {
    void (async () => {
      if ((await db.events.count()) === 0) await db.events.bulkPut(defaultClassEvents());
      await reload();
      setLoading(false);
    })();
  }, [reload]);

  return {events, wods, notes, loading, reload};
}

function useNow(interval = 30_000) {
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const timer = window.setInterval(() => setNow(new Date()), interval);
    return () => window.clearInterval(timer);
  }, [interval]);
  return now;
}

function applyStoredAppearance() {
  applyPreferences();
}

function App() {
  const data = useData();
  const [launching, setLaunching] = useState(true);
  const [onboarding, setOnboarding] = useState(localStorage.getItem('grid-onboarded') !== 'true');

  useEffect(() => {
    applyStoredAppearance();
    const timer = window.setTimeout(() => setLaunching(false), 760);
    return () => window.clearTimeout(timer);
  }, []);

  const finishOnboarding = () => {
    localStorage.setItem('grid-onboarded', 'true');
    setOnboarding(false);
  };

  return (
    <ToastProvider>
      <a className="skip-link" href="#grid-main">Skip to content</a>
      <div className="app">
        <AnimatePresence mode="wait">
          {(launching || data.loading) ? <LaunchScreen key="launch" /> : <Shell key="app" {...data} onReplayOnboarding={() => setOnboarding(true)} />}
        </AnimatePresence>
        <AnimatePresence>{!launching && !data.loading && onboarding && <Onboarding onComplete={finishOnboarding} />}</AnimatePresence>
      </div>
    </ToastProvider>
  );
}

function Shell({events, wods, notes, reload, onReplayOnboarding}: GridData & {onReplayOnboarding: () => void}) {
  const location = useLocation();
  const reduceMotion = useReducedMotion();
  return (
    <>
      <main id="grid-main">
        <AnimatePresence mode="wait" initial={false}>
          <motion.div
            key={location.pathname}
            className="route-stage"
            initial={reduceMotion ? false : {opacity: 0, y: 7, filter: 'blur(4px)'}}
            animate={{opacity: 1, y: 0, filter: 'blur(0px)'}}
            exit={reduceMotion ? undefined : {opacity: 0, y: -5, filter: 'blur(3px)'}}
            transition={{duration: 0.24, ease: [0.22, 1, 0.36, 1]}}
          >
            <Routes location={location}>
              <Route path="/" element={<Home events={events} wods={wods} notes={notes} reload={reload} />} />
              <Route path="/schedule" element={<Schedule events={events} reload={reload} />} />
              <Route path="/add" element={<QuickAdd reload={reload} />} />
              <Route path="/wod" element={<WodBuilder reload={reload} />} />
              <Route path="/ai" element={<AICoach events={events} wods={wods} notes={notes} />} />
              <Route path="/stats" element={<Stats events={events} wods={wods} reload={reload} />} />
              <Route path="/settings" element={<Settings reload={reload} onReplayOnboarding={onReplayOnboarding} />} />
            </Routes>
          </motion.div>
        </AnimatePresence>
      </main>
      <BottomNav />
    </>
  );
}

function GridMark() {
  return <span className="grid-mark" aria-hidden="true"><i /><i /><i /><i /><i /><i /><i /><i /><i /></span>;
}

function Header({eyebrow, title, action}: {eyebrow?: string; title: string; action?: React.ReactNode}) {
  return (
    <header className="top">
      <div className="title-lockup">
        <span className="eyebrow"><GridMark />{eyebrow || 'GRID'}</span>
        <h1>{title}</h1>
      </div>
      {action}
    </header>
  );
}

function BottomNav() {
  const items = [
    ['/', HomeIcon, 'Home'],
    ['/schedule', CalendarDays, 'Schedule'],
    ['/add', Plus, 'Add'],
    ['/wod', Activity, 'WOD'],
    ['/ai', Bot, 'Coach'],
    ['/stats', BarChart3, 'Stats'],
    ['/settings', SettingsIcon, 'Settings'],
  ] as const;

  return (
    <nav className="bottom" aria-label="Primary navigation">
      {items.map(([to, Icon, label]) => (
        <NavLink
          key={to}
          to={to}
          end={to === '/'}
          aria-label={label}
          onClick={() => haptic()}
          className={({isActive}: {isActive: boolean}) => `${isActive ? 'active' : ''} ${to === '/add' ? 'nav-add' : ''}`}
        >
          <span className="nav-icon"><Icon size={20} strokeWidth={2.1} /></span>
          <small>{label}</small>
        </NavLink>
      ))}
    </nav>
  );
}

function Home({events, wods, notes, reload}: {events: GridEvent[]; wods: Wod[]; notes: DayNote[]; reload: () => Promise<void>}) {
  const now = useNow();
  const today = new Date();
  const todays = events
    .filter((event) => isSameDay(parseISO(event.start), today))
    .sort((a, b) => a.start.localeCompare(b.start));
  const upcoming = events
    .filter((event) => parseISO(event.start) > now)
    .sort((a, b) => a.start.localeCompare(b.start));
  const next = todays.find((event) => parseISO(event.end) > now);
  const current = todays.find((event) => parseISO(event.start) <= now && parseISO(event.end) > now);
  const wod = wods.find((item) => item.date === todayKey());
  const note = notes.find((item) => item.date === todayKey());
  const weekStart = startOfWeek(today, {weekStartsOn: 1});
  const weekEnd = endOfWeek(today, {weekStartsOn: 1});
  const weekly = events.filter((event) => {
    const date = parseISO(event.start);
    return date >= weekStart && date <= weekEnd;
  });
  const complete = weekly.filter((event) => event.completed || parseISO(event.end) < now).length;
  const progress = weekly.length ? Math.round((complete / weekly.length) * 100) : 0;
  const countdown = next ? differenceInMinutes(parseISO(next.start), now) : null;
  const weeklyMinutes = weekly.reduce((sum, event) => sum + Math.max(0, differenceInMinutes(parseISO(event.end), parseISO(event.start))), 0);
  const studyMinutes = weekly.filter((event) => event.category === 'Study' || event.category === 'Class').reduce((sum, event) => sum + differenceInMinutes(parseISO(event.end), parseISO(event.start)), 0);
  const trainingCount = weekly.filter((event) => event.category === 'Training' || event.category === 'WOD').length;
  const deadlines = upcoming.filter((event) => /due|assignment|exam|deadline/i.test(event.title)).length;
  const dayLoad = todays.reduce((sum, event) => sum + differenceInMinutes(parseISO(event.end), parseISO(event.start)), 0);
  const loadScore = Math.min(100, Math.round(dayLoad / 5.4));
  const greeting = today.getHours() < 12 ? 'Morning' : today.getHours() < 18 ? 'Afternoon' : 'Evening';

  return (
    <Page onRefresh={reload}>
      <Header
        eyebrow={`${greeting} · ${format(today, 'd MMMM')}`}
        title="COMMAND"
        action={<button className="profile-button pressable" aria-label="Grid profile"><span>G</span><i /></button>}
      />

      <motion.section className="hero hero-home command-hero" whileTap={{scale: 0.994}} layout>
        <div className="hero-gridline" />
        <div className="hero-scan" />
        <div className="hero-content">
          <div className="status-pill"><i className={current ? 'live' : ''} />{current ? 'LIVE BLOCK' : next ? 'NEXT ON GRID' : 'OPEN WINDOW'}</div>
          <h2>{current?.title || next?.title || 'CLEAR RUNWAY'}</h2>
          <p>
            {current
              ? `${formatTime(parseISO(current.end))} finish · ${current.location || current.category}`
              : next
                ? `${countdown !== null && countdown > 0 ? `${formatCountdown(countdown)} away · ` : ''}${formatTime(parseISO(next.start))} · ${next.location || next.category}`
                : 'Your schedule is clear. Build a focused block or keep the recovery space.'}
          </p>
          <div className="hero-actions">
            <NavLink to="/schedule" className="hero-link">Open timeline <ArrowRight size={16} /></NavLink>
            <NavLink to="/add" className="hero-quick"><Plus size={15} /> Add block</NavLink>
          </div>
        </div>
        <ProgressRing value={progress} label="WEEK" />
      </motion.section>

      <div className="dashboard-grid" aria-label="Dashboard summary">
        <DashboardWidget icon={<Gauge />} value={`${loadScore}%`} label="Day load" trend={dayLoad > 360 ? 'High density' : 'Balanced'} meter={loadScore} />
        <DashboardWidget icon={<BookOpen />} value={`${(studyMinutes / 60).toFixed(studyMinutes % 60 ? 1 : 0)}h`} label="Academic load" trend={`${weekly.filter((event) => event.category === 'Class').length} class blocks`} />
        <DashboardWidget icon={<Dumbbell />} value={String(trainingCount).padStart(2, '0')} label="Training blocks" trend={wod ? 'Today programmed' : 'Builder ready'} />
        <DashboardWidget icon={<Target />} value={String(deadlines).padStart(2, '0')} label="Deadlines" trend={deadlines ? 'Action required' : 'No active flags'} />
      </div>

      <section className="signal-strip" aria-label="Weekly signal">
        <div><span>WEEKLY CAPACITY</span><b>{Math.round(weeklyMinutes / 60)} HOURS PLANNED</b></div>
        <PulseBars values={[42, 66, 54, 88, 61, 30, 20]} />
        <span className="signal-status"><i /> Synced locally</span>
      </section>

      <SectionTitle title="Today’s timeline" to="/schedule" link="Full schedule" />
      <AgendaList events={todays.slice(0, 5)} showNow />

      <SectionTitle title="Performance block" to="/wod" link="Open builder" />
      <NavLink to="/wod" className="card wod-card interactive-card pressable">
        <div className="card-glow" />
        <div className="wod-topline"><span className="tag">{wod?.type || 'READY TO BUILD'}</span><span className="wod-number">{wod ? '01' : '00'}</span></div>
        <h3>{wod?.name || 'PROGRAM TODAY’S SESSION'}</h3>
        <p>{wod?.movements.map((movement) => movement.name).join(' · ') || 'Create a clear stimulus, sequence movements and push it directly into today’s schedule.'}</p>
        <div className="workout-signal">
          <span><Timer size={15} />{wod?.timeCap ? `${wod.timeCap} min cap` : 'Flexible duration'}</span>
          <span><Activity size={15} />{wod ? `${wod.movements.length} movements` : 'Blank canvas'}</span>
        </div>
        <div className="card-footer"><span>{wod ? 'Scheduled in Grid' : 'Build from scratch or template'}</span><span className="circle-arrow"><ArrowRight size={17} /></span></div>
      </NavLink>

      <SectionTitle title="Daily focus" />
      <DailyFocusCard key={note?.updatedAt ?? 'daily-focus'} note={note} reload={reload} />

      <SectionTitle title="Next horizon" />
      <div className="horizon-rail">
        {upcoming.slice(0, 3).map((event) => <HorizonCard event={event} key={event.id} />)}
        {upcoming.length === 0 && <EmptyState icon={<CalendarClock />} title="Nothing ahead" text="Your next seven days are clear enough to design deliberately." action="Create a block" to="/add" />}
      </div>

      <blockquote className="quote-card"><Sparkles size={16} /><span>“{quotePool[today.getDate() % quotePool.length]}”</span><small>GRID DAILY SIGNAL</small></blockquote>
    </Page>
  );
}

function DashboardWidget({icon, value, label, trend, meter}: {icon: React.ReactNode; value: string; label: string; trend: string; meter?: number}) {
  return (
    <motion.article className="dashboard-widget pressable" whileTap={{scale: 0.98}}>
      <div className="widget-top"><span className="widget-icon">{icon}</span><ArrowUpRight size={15} /></div>
      <b>{value}</b>
      <span>{label}</span>
      <small>{trend}</small>
      {meter !== undefined && <div className="widget-meter"><i style={{width: `${meter}%`}} /></div>}
    </motion.article>
  );
}

function PulseBars({values}: {values: number[]}) {
  return <div className="pulse-bars" aria-hidden="true">{values.map((value, index) => <i key={index} style={{height: `${value}%`}} />)}</div>;
}

function DailyFocusCard({note, reload}: {note?: DayNote; reload: () => Promise<void>}) {
  const [content, setContent] = useState(note?.content ?? '');
  const [saved, setSaved] = useState(true);
  const [pinned, setPinned] = useState(note?.pinned ?? false);

  useEffect(() => {
    if (content === (note?.content ?? '')) return;
    setSaved(false);
    const timer = window.setTimeout(async () => {
      await db.notes.put({
        date: todayKey(),
        content,
        checklist: note?.checklist ?? [],
        pinned,
        updatedAt: new Date().toISOString(),
      });
      setSaved(true);
    }, 650);
    return () => window.clearTimeout(timer);
  }, [content, note?.checklist, note?.content, pinned]);

  const togglePin = async () => {
    const next = !pinned;
    setPinned(next);
    haptic();
    await db.notes.put({date: todayKey(), content, checklist: note?.checklist ?? [], pinned: next, updatedAt: new Date().toISOString()});
    await reload();
  };

  return (
    <article className={`focus-card ${pinned ? 'is-pinned' : ''}`}>
      <div className="focus-card-head">
        <span className="notes-icon"><MessageSquareText size={18} /></span>
        <div><b>One thing that matters</b><small>{saved ? 'Saved locally' : 'Saving changes…'}</small></div>
        <button className={pinned ? 'active' : ''} onClick={() => void togglePin()} aria-label={pinned ? 'Unpin daily focus' : 'Pin daily focus'}><Target size={18} /></button>
      </div>
      <textarea maxLength={320} value={content} onChange={(event) => setContent(event.target.value)} placeholder="Capture the priority, cue or reminder that should stay visible today." aria-label="Daily focus note" />
      <div className="autosave-row"><Lock size={13} /><span>Private on this device</span><span>{content.length}/320</span></div>
    </article>
  );
}

function HorizonCard({event}: {event: GridEvent}) {
  return (
    <NavLink to="/schedule" className="horizon-card pressable">
      <span className="horizon-date"><b>{format(parseISO(event.start), 'd')}</b><small>{format(parseISO(event.start), 'MMM')}</small></span>
      <div><small>{event.category}</small><b>{event.title}</b><span>{format(parseISO(event.start), 'EEE')} · {formatTime(parseISO(event.start))}</span></div>
      <i style={{background: event.colour || categoryColours[event.category]}} />
    </NavLink>
  );
}

function ProgressRing({value, label}: {value: number; label: string}) {
  return (
    <div className="progress-ring" style={{'--progress': `${value * 3.6}deg`} as React.CSSProperties}>
      <div><b>{value}%</b><small>{label}</small></div>
    </div>
  );
}

function SectionTitle({title, link, to}: {title: string; link?: string; to?: string}) {
  return (
    <div className="section-title">
      <div><span>GRID</span><h2>{title}</h2></div>
      {link && to && <NavLink to={to}>{link}<ChevronRight size={15} /></NavLink>}
    </div>
  );
}

function EventRow({event, onClick, compact = false}: {event: GridEvent; onClick?: () => void; compact?: boolean}) {
  const start = parseISO(event.start);
  const end = parseISO(event.end);
  const duration = differenceInMinutes(end, start);
  const active = start <= new Date() && end > new Date();
  return (
    <motion.button
      className={`event-row ${compact ? 'compact-row' : ''} ${event.completed ? 'is-complete' : ''} ${active ? 'is-live' : ''}`}
      onClick={() => {haptic(); onClick?.();}}
      whileTap={{scale: 0.988}}
      type="button"
    >
      <div className="time-block"><b>{formatTime(start)}</b><span>{formatTime(end)}</span></div>
      <div className="timeline-node" style={{'--event-colour': event.colour || categoryColours[event.category]} as React.CSSProperties}><i /></div>
      <div className="event-copy">
        <div className="event-overline"><span className="event-category">{event.category}</span>{active && <span className="live-label">LIVE</span>}</div>
        <b>{event.title}</b>
        <span>{event.location || `${duration} min block`}</span>
      </div>
      <div className="event-tail"><small>{duration}m</small><ChevronRight size={18} /></div>
    </motion.button>
  );
}

function AgendaList({events, showNow = false, onEvent}: {events: GridEvent[]; showNow?: boolean; onEvent?: (event: GridEvent) => void}) {
  const now = new Date();
  let nowInserted = false;
  const rows: React.ReactNode[] = [];

  events.forEach((event) => {
    if (showNow && isToday(parseISO(event.start)) && !nowInserted && parseISO(event.start) > now) {
      rows.push(<NowMarker key="now" />);
      nowInserted = true;
    }
    rows.push(<EventRow key={event.id} event={event} onClick={onEvent ? () => onEvent(event) : undefined} />);
  });
  if (showNow && events.length > 0 && isToday(parseISO(events[0].start)) && !nowInserted) rows.push(<NowMarker key="now" />);

  return (
    <div className="agenda-list">
      {rows.length ? rows : <EmptyState icon={<CalendarDays />} title="Clear schedule" text="Nothing is scheduled here. Protect the whitespace or add a focused block." action="Add event" to="/add" />}
    </div>
  );
}

function NowMarker() {
  return <div className="now-marker"><span>{formatTime(new Date())}</span><i /><b>NOW</b></div>;
}

function Schedule({events, reload}: {events: GridEvent[]; reload: () => Promise<void>}) {
  const [date, setDate] = useState(new Date());
  const [query, setQuery] = useState('');
  const [editing, setEditing] = useState<GridEvent | null>(null);
  const [view, setView] = useState<ScheduleView>('day');
  const [filter, setFilter] = useState<'All' | Category>('All');
  const [refreshing, setRefreshing] = useState(false);
  const reduceMotion = useReducedMotion();

  const filtered = useMemo(() => events.filter((event) => {
    const searchTarget = `${event.title} ${event.location ?? ''} ${event.category}`.toLowerCase();
    return searchTarget.includes(query.toLowerCase()) && (filter === 'All' || event.category === filter);
  }), [events, filter, query]);

  const daily = filtered
    .filter((event) => isSameDay(parseISO(event.start), date))
    .sort((a, b) => a.start.localeCompare(b.start));
  const dailyMinutes = daily.reduce((sum, event) => sum + Math.max(0, differenceInMinutes(parseISO(event.end), parseISO(event.start))), 0);
  const dailyLoad = Math.min(100, Math.round(dailyMinutes / 5.4));
  const firstBlock = daily[0];
  const lastBlock = daily[daily.length - 1];

  const stepDay = (direction: number) => {
    haptic(6);
    const increment = view === 'day' ? 1 : view === 'week' ? 7 : 28;
    setDate((current) => addDays(current, direction * increment));
  };

  const refresh = async () => {
    setRefreshing(true);
    await reload();
    window.setTimeout(() => setRefreshing(false), 350);
  };

  return (
    <Page onRefresh={refresh}>
      <Header
        title="SCHEDULE"
        action={<button className="icon-btn" aria-label="Refresh schedule" onClick={() => void refresh()}><RefreshCw className={refreshing ? 'spinning' : ''} size={19} /></button>}
      />

      <div className="segmented" aria-label="Schedule view">
        {(['day', 'week', 'month'] as ScheduleView[]).map((item) => (
          <button key={item} className={view === item ? 'selected' : ''} onClick={() => {haptic(); setView(item);}}>{item}</button>
        ))}
      </div>

      <div className="date-control">
        <button className="mini-icon" onClick={() => stepDay(-1)} aria-label="Previous day"><ChevronLeft /></button>
        <button className="date-title" onClick={() => setDate(new Date())}>
          <span>{format(date, 'MMMM yyyy')}</span>
          <b>{isToday(date) ? 'Today' : format(date, 'EEEE d')}</b>
        </button>
        <button className="mini-icon" onClick={() => stepDay(1)} aria-label="Next day"><ChevronRight /></button>
      </div>

      <div className="date-strip" role="list">
        {[-3, -2, -1, 0, 1, 2, 3].map((offset) => {
          const item = addDays(date, offset);
          const active = offset === 0;
          const hasEvents = events.some((event) => isSameDay(parseISO(event.start), item));
          return (
            <button className={active ? 'selected' : ''} onClick={() => {haptic(); setDate(item);}} key={item.toISOString()}>
              <span>{format(item, 'EEE')}</span><b>{format(item, 'd')}</b>{hasEvents && <i />}
            </button>
          );
        })}
      </div>

      <label className="search">
        <Search size={18} />
        <input value={query} onChange={(event: React.ChangeEvent<HTMLInputElement>) => setQuery(event.target.value)} placeholder="Search schedule" aria-label="Search schedule" />
        {query && <button onClick={() => setQuery('')} aria-label="Clear search"><X size={16} /></button>}
      </label>

      <div className="filter-row" aria-label="Event filters">
        <ListFilter size={16} />
        {(['All', ...categories] as const).map((item) => (
          <button key={item} className={filter === item ? 'active' : ''} onClick={() => {haptic(); setFilter(item);}}>{item}</button>
        ))}
      </div>

      {view === 'day' && (
        <section className="schedule-overview" aria-label="Day schedule summary">
          <div className="load-gauge" style={{'--load': `${dailyLoad * 3.6}deg`} as React.CSSProperties}><span>{dailyLoad}%</span></div>
          <div><span className="micro-label">DAY DENSITY</span><b>{daily.length ? `${daily.length} blocks · ${formatDuration(dailyMinutes)}` : 'Open day'}</b><small>{firstBlock && lastBlock ? `${formatTime(parseISO(firstBlock.start))}–${formatTime(parseISO(lastBlock.end))} operating window` : 'No fixed commitments detected'}</small></div>
          <span className={`density-badge ${dailyLoad > 75 ? 'high' : dailyLoad > 45 ? 'medium' : ''}`}>{dailyLoad > 75 ? 'HIGH' : dailyLoad > 45 ? 'BALANCED' : 'LIGHT'}</span>
        </section>
      )}

      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={`${view}-${format(date, 'yyyy-MM-dd')}`}
          className="schedule-stage"
          initial={reduceMotion ? false : {opacity: 0, x: 14}}
          animate={{opacity: 1, x: 0}}
          exit={reduceMotion ? undefined : {opacity: 0, x: -14}}
          transition={{duration: 0.2}}
          drag={view === 'day' ? 'x' : false}
          dragConstraints={{left: 0, right: 0}}
          dragElastic={0.14}
          onDragEnd={(_: unknown, info: {offset: {x: number}}) => {
            if (info.offset.x < -72) stepDay(1);
            if (info.offset.x > 72) stepDay(-1);
          }}
        >
          {view === 'day' && (
            <>
              <div className="schedule-head">
                <div><span className="eyebrow">{daily.length.toString().padStart(2, '0')} BLOCKS</span><h2>{format(date, 'EEEE d')}</h2></div>
                {!isToday(date) && <button className="text-btn" onClick={() => setDate(new Date())}>Today</button>}
              </div>
              <AgendaList events={daily} showNow onEvent={setEditing} />
              <p className="swipe-hint"><ChevronLeft size={14} /> Swipe to change day <ChevronRight size={14} /></p>
            </>
          )}
          {view === 'week' && <WeekView date={date} events={filtered} onSelect={(item) => {setDate(item); setView('day');}} />}
          {view === 'month' && <MonthView date={date} events={filtered} onSelect={(item) => {setDate(item); setView('day');}} />}
        </motion.div>
      </AnimatePresence>

      <NavLink className="fab" to="/add" aria-label="Add event" onClick={() => haptic()}><Plus /></NavLink>
      <AnimatePresence>{editing && <EventModal event={editing} close={() => setEditing(null)} reload={reload} />}</AnimatePresence>
    </Page>
  );
}

function WeekView({date, events, onSelect}: {date: Date; events: GridEvent[]; onSelect: (date: Date) => void}) {
  const days = eachDayOfInterval({start: startOfWeek(date, {weekStartsOn: 1}), end: endOfWeek(date, {weekStartsOn: 1})});
  return (
    <div className="week-view">
      {days.map((day) => {
        const items = events.filter((event) => isSameDay(parseISO(event.start), day)).sort((a, b) => a.start.localeCompare(b.start));
        return (
          <button key={day.toISOString()} className={`week-day ${isToday(day) ? 'today' : ''}`} onClick={() => onSelect(day)}>
            <div className="week-day-title"><span>{format(day, 'EEE')}</span><b>{format(day, 'd')}</b><small>{items.length}</small></div>
            <div className="week-events">
              {items.slice(0, 3).map((event) => <i key={event.id} style={{background: event.colour || categoryColours[event.category]}} title={event.title} />)}
              <span>{items[0]?.title || 'Open day'}</span>
            </div>
          </button>
        );
      })}
    </div>
  );
}

function MonthView({date, events, onSelect}: {date: Date; events: GridEvent[]; onSelect: (date: Date) => void}) {
  const monthStart = startOfMonth(date);
  const days = eachDayOfInterval({
    start: startOfWeek(monthStart, {weekStartsOn: 1}),
    end: endOfWeek(endOfMonth(date), {weekStartsOn: 1}),
  });
  return (
    <div className="month-shell">
      <div className="month-weekdays">{['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((item, index) => <span key={`${item}-${index}`}>{item}</span>)}</div>
      <div className="month-grid">
        {days.map((day) => {
          const items = events.filter((event) => isSameDay(parseISO(event.start), day));
          return (
            <button key={day.toISOString()} className={`${!isSameMonth(day, date) ? 'outside' : ''} ${isToday(day) ? 'today' : ''}`} onClick={() => onSelect(day)}>
              <b>{format(day, 'd')}</b>
              <span>{items.slice(0, 3).map((event) => <i key={event.id} style={{background: event.colour || categoryColours[event.category]}} />)}</span>
            </button>
          );
        })}
      </div>
    </div>
  );
}

function EventModal({event, close, reload}: {event: GridEvent; close: () => void; reload: () => Promise<void>}) {
  const {notify} = useToast();
  const [editing, setEditing] = useState(false);
  const [title, setTitle] = useState(event.title);
  const [location, setLocation] = useState(event.location ?? '');
  const [category, setCategory] = useState<Category>(event.category);
  const [startValue, setStartValue] = useState(format(parseISO(event.start), "yyyy-MM-dd'T'HH:mm"));
  const [endValue, setEndValue] = useState(format(parseISO(event.end), "yyyy-MM-dd'T'HH:mm"));
  const [notes, setNotes] = useState(event.notes ?? '');

  const duplicate = async () => {
    const start = addDays(parseISO(event.start), 1);
    const end = addDays(parseISO(event.end), 1);
    await db.events.put({...event, id: uid(), title: `${event.title} copy`, start: start.toISOString(), end: end.toISOString()});
    await reload();
    notify('Event duplicated for tomorrow');
    close();
  };

  const remove = async () => {
    if (!window.confirm(`Delete “${event.title}”?`)) return;
    await db.events.delete(event.id);
    await reload();
    notify('Event deleted', 'info');
    close();
  };

  const toggleComplete = async () => {
    await db.events.update(event.id, {completed: !event.completed});
    await reload();
    notify(event.completed ? 'Event marked active' : 'Event completed');
    close();
  };

  const save = async () => {
    const start = new Date(startValue);
    const end = new Date(endValue);
    if (!title.trim() || Number.isNaN(start.getTime()) || Number.isNaN(end.getTime()) || end <= start) {
      notify('Check the event title and time range', 'warning');
      return;
    }
    await db.events.update(event.id, {
      title: title.trim(),
      location: location.trim() || undefined,
      category,
      start: start.toISOString(),
      end: end.toISOString(),
      notes: notes.trim() || undefined,
      colour: categoryColours[category],
    });
    await reload();
    notify('Event updated');
    close();
  };

  return (
    <motion.div className="overlay" initial={{opacity: 0}} animate={{opacity: 1}} exit={{opacity: 0}} onClick={close} role="presentation">
      <motion.div
        className="sheet event-sheet"
        initial={{y: '100%', scale: 0.98}}
        animate={{y: 0, scale: 1}}
        exit={{y: '100%', scale: 0.98}}
        transition={{type: 'spring', damping: 30, stiffness: 330}}
        onClick={(click: React.MouseEvent<HTMLDivElement>) => click.stopPropagation()}
        role="dialog"
        aria-modal="true"
        aria-label={`${event.title} event details`}
      >
        <div className="sheet-handle" />
        <button className="close pressable" onClick={close} aria-label="Close event"><X /></button>
        {!editing ? (
          <>
            <div className="sheet-topline"><span className="tag" style={{background: event.colour || categoryColours[event.category]}}>{event.category}</span>{event.completed && <span className="complete-chip"><CheckCircle2 size={14} /> COMPLETE</span>}</div>
            <h2>{event.title}</h2>
            <div className="event-detail"><Clock size={18} /><span>{format(parseISO(event.start), 'EEEE d MMM · ')}{formatTime(parseISO(event.start))}–{formatTime(parseISO(event.end))}</span></div>
            {event.location && <div className="event-detail"><MapPin size={18} /><span>{event.location}</span></div>}
            {event.notes && <div className="detail-note">{event.notes}</div>}
            <div className="event-action-grid">
              <button onClick={() => {haptic(); setEditing(true);}}><Pencil />Edit</button>
              <button onClick={() => void toggleComplete()}><CheckCircle2 />{event.completed ? 'Reopen' : 'Complete'}</button>
              <button onClick={() => void duplicate()}><Copy />Duplicate</button>
              <button className="danger" onClick={() => void remove()}><Trash2 />Delete</button>
            </div>
          </>
        ) : (
          <>
            <span className="eyebrow"><Pencil size={14} />EDIT BLOCK</span>
            <h2>REFINE EVENT</h2>
            <div className="edit-event-form">
              <label className="field">Title<input value={title} onChange={(input) => setTitle(input.target.value)} /></label>
              <div className="field-pair">
                <label className="field">Starts<input type="datetime-local" value={startValue} onChange={(input) => setStartValue(input.target.value)} /></label>
                <label className="field">Ends<input type="datetime-local" value={endValue} onChange={(input) => setEndValue(input.target.value)} /></label>
              </div>
              <label className="field">Category<select value={category} onChange={(input) => setCategory(input.target.value as Category)}>{categories.map((item) => <option key={item}>{item}</option>)}</select></label>
              <label className="field">Location<input value={location} onChange={(input) => setLocation(input.target.value)} placeholder="Optional" /></label>
              <label className="field">Notes<textarea value={notes} onChange={(input) => setNotes(input.target.value)} placeholder="Context, preparation or reminders" /></label>
            </div>
            <div className="actions"><button onClick={() => setEditing(false)}>Cancel</button><button className="primary-inline" onClick={() => void save()}><Check />Save changes</button></div>
          </>
        )}
      </motion.div>
    </motion.div>
  );
}

function QuickAdd({reload}: {reload: () => Promise<void>}) {
  const navigate = useNavigate();
  const {notify} = useToast();
  const [input, setInput] = useState('');
  const [parsed, setParsed] = useState<ReturnType<typeof parseQuickAdd> | null>(null);
  const [analysing, setAnalysing] = useState(false);

  const analyse = () => {
    if (!input.trim()) return;
    setAnalysing(true);
    window.setTimeout(() => {
      setParsed(parseQuickAdd(input));
      setAnalysing(false);
      haptic(12);
    }, 320);
  };

  const save = async () => {
    if (!parsed) return;
    await db.events.put({
      id: uid(),
      title: parsed.title,
      start: parsed.date.toISOString(),
      end: addMinutes(parsed.date, parsed.duration || 60).toISOString(),
      category: parsed.category,
      notes: parsed.notes,
      colour: categoryColours[parsed.category],
    });
    await reload();
    notify('Added to your schedule');
    navigate('/schedule');
  };

  return (
    <Page>
      <Header title="QUICK ADD" action={<div className="feature-icon"><Zap size={20} /></div>} />
      <div className="intro-block">
        <span className="kicker">NATURAL LANGUAGE</span>
        <p className="lead">Write it the way you would say it. Grid turns the detail into a structured event, then asks you to confirm.</p>
      </div>
      <div className={`command-shell ${input ? 'has-value' : ''}`}>
        <Sparkles size={20} />
        <textarea autoFocus maxLength={160} value={input} onChange={(event: React.ChangeEvent<HTMLTextAreaElement>) => {setInput(event.target.value); setParsed(null);}} placeholder="CrossFit tomorrow at 6pm" />
        <span>{input.length}/160</span>
      </div>
      <div className="chips">
        {['Physio Friday 9am', 'Study Monday 7pm', 'Coffee Saturday 1300', 'Assignment due Tuesday'].map((example) => (
          <button onClick={() => {setInput(example); setParsed(null);}} key={example}>{example}</button>
        ))}
      </div>
      <button className="primary" disabled={!input.trim() || analysing} onClick={analyse}>
        {analysing ? <><RefreshCw className="spinning" />Structuring event</> : <><Sparkles />Analyse event</>}
      </button>
      <AnimatePresence>
        {parsed && (
          <motion.article className="confirm card" initial={{opacity: 0, y: 18}} animate={{opacity: 1, y: 0}} exit={{opacity: 0, y: 10}}>
            <div className="confirm-head"><span className="eyebrow"><Check size={14} />READY TO CONFIRM</span><span className="category-dot" style={{background: categoryColours[parsed.category]}} /></div>
            <h2>{parsed.title}</h2>
            <div className="confirmation-grid">
              <div><Clock /><span>Date & time</span><b>{format(parsed.date, 'EEE d MMM')} · {formatTime(parsed.date)}</b></div>
              <div><Layers3 /><span>Category</span><b>{parsed.category}</b></div>
              <div><Timer /><span>Duration</span><b>{parsed.duration || 60} min</b></div>
            </div>
            <button className="primary" onClick={() => void save()}>Save to Grid <ArrowRight /></button>
          </motion.article>
        )}
      </AnimatePresence>
    </Page>
  );
}

function WodBuilder({reload}: {reload: () => Promise<void>}) {
  const navigate = useNavigate();
  const {notify} = useToast();
  const [name, setName] = useState('');
  const [type, setType] = useState<Wod['type']>('For Time');
  const [timeCap, setTimeCap] = useState('');
  const [rounds, setRounds] = useState('');
  const [rx, setRx] = useState('');
  const [scaled, setScaled] = useState('');
  const [notes, setNotes] = useState('');
  const [movements, setMovements] = useState<WodMovement[]>([{id: uid(), name: '', details: ''}]);
  const formats: Wod['type'][] = ['For Time', 'EMOM', 'AMRAP', 'Strength', 'Chipper', 'Intervals', 'Custom'];
  const movementLibrary = ['Bike', 'Run', 'Row', 'Front Squat', 'Deadlift', 'Pull-up', 'Burpee', 'Box Jump', 'DB Snatch', 'Toes-to-bar'];
  const templates: {name: string; type: Wod['type']; cap: string; rounds: string; movements: Array<[string, string]>}[] = [
    {name: 'Engine Builder', type: 'AMRAP', cap: '20', rounds: '', movements: [['Bike', '12 calories'], ['Front Squat', '10 reps'], ['Pull-up', '8 reps']]},
    {name: 'Strength Base', type: 'Strength', cap: '35', rounds: '5', movements: [['Back Squat', '5 reps @ RPE 7'], ['Romanian Deadlift', '8 reps'], ['Farmer Carry', '40 m']]},
    {name: 'Fast Chipper', type: 'Chipper', cap: '18', rounds: '1', movements: [['Run', '800 m'], ['DB Snatch', '50 alternating'], ['Burpee', '30 reps'], ['Run', '400 m']]},
  ];

  const validMovementCount = movements.filter((movement) => movement.name.trim()).length;
  const completion = Math.round(((name.trim() ? 1 : 0) + (validMovementCount ? 1 : 0) + ((rx || scaled || notes) ? 1 : 0)) / 3 * 100);

  const updateMovement = (id: string, key: 'name' | 'details', value: string) => {
    setMovements((current) => current.map((movement) => movement.id === id ? {...movement, [key]: value} : movement));
  };

  const removeMovement = (id: string) => {
    if (movements.length === 1) return;
    haptic();
    setMovements((current) => current.filter((movement) => movement.id !== id));
  };

  const addLibraryMovement = (movementName: string) => {
    haptic();
    setMovements((current) => {
      const empty = current.find((movement) => !movement.name.trim());
      if (empty) return current.map((movement) => movement.id === empty.id ? {...movement, name: movementName} : movement);
      return [...current, {id: uid(), name: movementName, details: ''}];
    });
  };

  const applyTemplate = (template: typeof templates[number]) => {
    haptic(12);
    setName(template.name);
    setType(template.type);
    setTimeCap(template.cap);
    setRounds(template.rounds);
    setMovements(template.movements.map(([movementName, details]) => ({id: uid(), name: movementName, details})));
    notify(`${template.name} loaded`, 'info');
  };

  const save = async () => {
    const validMovements = movements.filter((movement) => movement.name.trim());
    if (!name.trim() || validMovements.length === 0) {
      notify('Add a workout name and at least one movement', 'warning');
      return;
    }
    const id = uid();
    const date = todayKey();
    await db.wods.put({
      id,
      name: name.trim(),
      type,
      date,
      timeCap: timeCap ? Number(timeCap) : undefined,
      rounds: rounds ? Number(rounds) : undefined,
      rx: rx || undefined,
      scaled: scaled || undefined,
      notes: notes || undefined,
      movements: validMovements,
    });
    const start = set(new Date(), {hours: 17, minutes: 0, seconds: 0, milliseconds: 0});
    await db.events.put({
      id: `wod-${id}`,
      title: name.trim(),
      start: start.toISOString(),
      end: addMinutes(start, Number(timeCap) || 60).toISOString(),
      category: 'WOD',
      colour: categoryColours.WOD,
      notes: validMovements.map((movement) => `${movement.name}${movement.details ? ` — ${movement.details}` : ''}`).join('\n'),
    });
    await reload();
    notify('Workout saved and scheduled');
    navigate('/');
  };

  return (
    <Page>
      <Header title="WOD LAB" action={<div className="feature-icon"><Dumbbell size={20} /></div>} />
      <section className="builder-hero premium-builder-hero">
        <div><span className="kicker">PERFORMANCE DESIGN</span><h2>{name || 'UNTITLED SESSION'}</h2><p>{type} · {validMovementCount} movements · {timeCap ? `${timeCap} min` : 'open duration'}</p></div>
        <div className="builder-completion"><ProgressRing value={completion} label="BUILT" /></div>
      </section>

      <div className="template-rail" aria-label="Workout templates">
        {templates.map((template, index) => (
          <button key={template.name} onClick={() => applyTemplate(template)} className="template-card pressable">
            <span>0{index + 1}</span><b>{template.name}</b><small>{template.type} · {template.cap} min</small><ArrowUpRight size={16} />
          </button>
        ))}
      </div>

      <div className="builder-section">
        <div className="builder-section-title"><span>01</span><div><b>Session identity</b><small>Name the stimulus and choose its structure</small></div>{name && <CheckCircle2 className="section-check" />}</div>
        <div className="form-card">
          <label className="field">Workout name<input value={name} onChange={(event) => setName(event.target.value)} placeholder="Friday Engine" /></label>
          <div className="format-picker" role="listbox" aria-label="Workout format">
            {formats.map((item) => <button role="option" aria-selected={type === item} className={type === item ? 'active' : ''} key={item} onClick={() => {haptic(); setType(item);}}>{item}</button>)}
          </div>
          <div className="field-pair">
            <label className="field">Time cap<input inputMode="numeric" value={timeCap} onChange={(event) => setTimeCap(event.target.value.replace(/\D/g, ''))} placeholder="Minutes" /></label>
            <label className="field">Rounds<input inputMode="numeric" value={rounds} onChange={(event) => setRounds(event.target.value.replace(/\D/g, ''))} placeholder="Optional" /></label>
          </div>
        </div>
      </div>

      <div className="builder-section">
        <div className="builder-section-title"><span>02</span><div><b>Movement sequence</b><small>Tap the library or hold and drag to reorder</small></div>{validMovementCount > 0 && <CheckCircle2 className="section-check" />}</div>
        <div className="movement-library" aria-label="Movement library">{movementLibrary.map((item) => <button key={item} onClick={() => addLibraryMovement(item)}><Plus size={13} />{item}</button>)}</div>
        <Reorder.Group axis="y" values={movements} onReorder={setMovements} className="movement-list">
          {movements.map((movement, index) => (
            <Reorder.Item value={movement} key={movement.id} className="movement-card" whileDrag={{scale: 1.018, zIndex: 4, boxShadow: '0 26px 70px rgba(0,0,0,.36)'}}>
              <button className="drag-handle" aria-label={`Reorder movement ${index + 1}`}><GripVertical /></button>
              <div className="movement-index">{String(index + 1).padStart(2, '0')}</div>
              <div className="movement-inputs">
                <input value={movement.name} onChange={(event) => updateMovement(movement.id, 'name', event.target.value)} placeholder="Movement" aria-label={`Movement ${index + 1}`} />
                <input value={movement.details} onChange={(event) => updateMovement(movement.id, 'details', event.target.value)} placeholder="Reps · load · distance" aria-label={`Movement ${index + 1} details`} />
              </div>
              <button className="remove-movement" onClick={() => removeMovement(movement.id)} aria-label={`Remove movement ${index + 1}`} disabled={movements.length === 1}><X /></button>
            </Reorder.Item>
          ))}
        </Reorder.Group>
        <button className="secondary add-movement" onClick={() => setMovements((current) => [...current, {id: uid(), name: '', details: ''}])}><Plus />Add custom movement</button>
      </div>

      <div className="builder-section">
        <div className="builder-section-title"><span>03</span><div><b>Standards & intent</b><small>Make the execution unambiguous</small></div>{(rx || scaled || notes) && <CheckCircle2 className="section-check" />}</div>
        <div className="form-card">
          <div className="field-pair">
            <label className="field">RX<input value={rx} onChange={(event) => setRx(event.target.value)} placeholder="e.g. 60 kg" /></label>
            <label className="field">Scaled<input value={scaled} onChange={(event) => setScaled(event.target.value)} placeholder="e.g. 40 kg" /></label>
          </div>
          <label className="field">Coach notes<textarea value={notes} onChange={(event) => setNotes(event.target.value)} placeholder="Pacing, stimulus and movement standards" /></label>
        </div>
      </div>

      <article className="wod-preview premium-preview">
        <div className="preview-grid" />
        <div className="preview-top"><span className="tag">{type}</span><span>{timeCap ? `${timeCap} MIN CAP` : 'NO CAP'}</span></div>
        <h2>{name || 'SESSION PREVIEW'}</h2>
        <div className="preview-meta"><span><Timer size={15} />{rounds ? `${rounds} rounds` : 'Custom volume'}</span><span><Gauge size={15} />{rx || 'RX open'}</span></div>
        <ol>{movements.filter((movement) => movement.name).map((movement) => <li key={movement.id}><b>{movement.name}</b><span>{movement.details || 'Details open'}</span></li>)}</ol>
        {!movements.some((movement) => movement.name) && <p>Add movements to build the live preview.</p>}
        {notes && <div className="preview-note"><MessageSquareText size={15} />{notes}</div>}
      </article>

      <button className="primary sticky-action haptic-action" onClick={() => void save()}><span>Save workout</span><ArrowRight /></button>
    </Page>
  );
}

type CoachMessage = {
  id: string;
  role: 'user' | 'coach';
  text?: string;
  response?: CoachResponse;
  createdAt: string;
};

function AICoach({events, wods, notes}: {events: GridEvent[]; wods: Wod[]; notes: DayNote[]}) {
  const {notify} = useToast();
  const [mode, setMode] = useState<CoachMode>('Plan');
  const [messages, setMessages] = useState<CoachMessage[]>(() => {
    try {
      const stored = localStorage.getItem('grid-coach-thread');
      if (stored) return JSON.parse(stored) as CoachMessage[];
    } catch {
      localStorage.removeItem('grid-coach-thread');
    }
    return [{
      id: uid(),
      role: 'coach',
      response: {
        title: 'Grid Coach online — locally',
        summary: 'I can structure training, study blocks, recovery and weekly plans without sending your data off this device.',
        steps: ['Choose a mode.', 'Use a suggested prompt or write your own.', 'Refine the answer until it fits your day.'],
        footer: 'Version 1 uses a private offline response engine.',
      },
      createdAt: new Date().toISOString(),
    }];
  });
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const now = new Date();
  const weekStart = startOfWeek(now, {weekStartsOn: 1});
  const weekEnd = endOfWeek(now, {weekStartsOn: 1});
  const eventsToday = events.filter((event) => isSameDay(parseISO(event.start), now));
  const eventsThisWeek = events.filter((event) => parseISO(event.start) >= weekStart && parseISO(event.start) <= weekEnd);
  const nextEvent = events.filter((event) => parseISO(event.start) > now).sort((a, b) => a.start.localeCompare(b.start))[0];
  const note = notes.find((item) => item.date === todayKey());
  const hasWodToday = wods.some((item) => item.date === todayKey());

  const promptSets: Record<CoachMode, string[]> = {
    Plan: ['Optimise my day around my timetable', 'Plan the rest of my week', 'Find a two-hour focus window'],
    Train: ['Build a 45-minute leg session', 'Generate tomorrow’s WOD', 'Create a low-equipment conditioning session'],
    Study: ['Plan study around my classes', 'Create an exam revision structure', 'Turn today into focused study blocks'],
    Recover: ['Suggest recovery training', 'Create a lower-load day', 'Help me protect sleep tonight'],
  };

  useEffect(() => {
    localStorage.setItem('grid-coach-thread', JSON.stringify(messages.slice(-30)));
  }, [messages]);

  const send = (preset?: string) => {
    const question = (preset ?? input).trim();
    if (!question || thinking) return;
    haptic();
    const userMessage: CoachMessage = {id: uid(), role: 'user', text: question, createdAt: new Date().toISOString()};
    setMessages((current) => [...current, userMessage]);
    setInput('');
    setThinking(true);
    window.setTimeout(() => {
      const response = generateOfflineCoachResponse(question, mode, {
        eventsToday: eventsToday.length,
        eventsThisWeek: eventsThisWeek.length,
        nextEvent: nextEvent ? `${nextEvent.title} at ${formatTime(parseISO(nextEvent.start))}` : undefined,
        hasWodToday,
        note: note?.content,
      });
      setMessages((current) => [...current, {id: uid(), role: 'coach', response, createdAt: new Date().toISOString()}]);
      setThinking(false);
      haptic(12);
    }, 620);
  };

  const clear = () => {
    if (!window.confirm('Clear the local Grid Coach conversation?')) return;
    localStorage.removeItem('grid-coach-thread');
    setMessages([]);
    notify('Coach thread cleared', 'info');
  };

  const copyResponse = async (response: CoachResponse) => {
    const text = `${response.title}\n\n${response.summary}\n\n${response.steps.map((step, index) => `${index + 1}. ${step}`).join('\n')}\n\n${response.footer}`;
    await navigator.clipboard.writeText(text);
    notify('Coach plan copied');
  };

  return (
    <Page>
      <Header
        title="GRID COACH"
        action={<div className="header-actions"><div className="offline-pill"><i />PRIVATE</div><button className="icon-btn" onClick={clear} aria-label="Clear coach conversation"><Trash2 size={17} /></button></div>}
      />
      <section className="coach-command">
        <div className="coach-orb"><Brain /></div>
        <div><span className="kicker">LOCAL INTELLIGENCE</span><h2>Think in systems.</h2><p>Schedule-aware guidance without leaving your device.</p></div>
        <span className="coach-version">V1<br />OFFLINE</span>
      </section>

      <div className="coach-modes" role="tablist" aria-label="Coach mode">
        {([
          ['Plan', CalendarClock],
          ['Train', Dumbbell],
          ['Study', GraduationCap],
          ['Recover', HeartPulse],
        ] as const).map(([item, Icon]) => (
          <button role="tab" aria-selected={mode === item} className={mode === item ? 'active' : ''} key={item} onClick={() => {haptic(); setMode(item);}}><Icon size={17} /><span>{item}</span></button>
        ))}
      </div>

      <section className="coach-context" aria-label="Coach context">
        <div><span>CONTEXT WINDOW</span><b>{eventsToday.length} today · {eventsThisWeek.length} this week</b></div>
        <div className="context-signals"><span className={hasWodToday ? 'active' : ''}><Dumbbell size={14} />WOD</span><span className={note?.content ? 'active' : ''}><MessageSquareText size={14} />NOTE</span><span className="active"><Lock size={14} />LOCAL</span></div>
      </section>

      <div className="prompt-rail premium-prompts">{promptSets[mode].map((prompt) => <button key={prompt} onClick={() => send(prompt)}><Sparkles size={15} /><span>{prompt}</span><ArrowUpRight size={14} /></button>)}</div>

      <div className="chat premium-chat" aria-live="polite">
        {messages.length === 0 && <EmptyState icon={<Brain />} title="Fresh coach thread" text="Choose a mode and ask Grid Coach to design the next decision." />}
        {messages.map((message) => (
          <motion.div key={message.id} className={`message-row ${message.role}`} initial={{opacity: 0, y: 12, scale: 0.985}} animate={{opacity: 1, y: 0, scale: 1}}>
            {message.role === 'coach' && <span className="message-avatar"><GridMark /></span>}
            {message.role === 'user' ? <div className="bubble user">{message.text}</div> : message.response && (
              <article className="coach-response">
                <div className="response-head"><span>GRID / {mode.toUpperCase()}</span><button onClick={() => void copyResponse(message.response!)} aria-label="Copy coach response"><Copy size={15} /></button></div>
                <h3>{message.response.title}</h3>
                <p>{message.response.summary}</p>
                <ol>{message.response.steps.map((step, index) => <li key={`${message.id}-${index}`}><span>{String(index + 1).padStart(2, '0')}</span><p>{step}</p></li>)}</ol>
                <footer><ShieldCheck size={15} /><span>{message.response.footer}</span></footer>
              </article>
            )}
          </motion.div>
        ))}
        {thinking && <div className="message-row coach"><span className="message-avatar"><GridMark /></span><div className="bubble coach typing"><i /><i /><i /></div></div>}
      </div>
      <div className="composer premium-composer">
        <input value={input} onChange={(event) => setInput(event.target.value)} onKeyDown={(event) => {if (event.key === 'Enter') send();}} placeholder={`Ask ${mode.toLowerCase()} coach…`} aria-label="Message Grid Coach" />
        <button onClick={() => send()} disabled={!input.trim() || thinking} aria-label="Send message"><Send /></button>
      </div>
    </Page>
  );
}

function Stats({events, wods, reload}: {events: GridEvent[]; wods: Wod[]; reload: () => Promise<void>}) {
  const now = new Date();
  const last30Start = subDays(now, 30);
  const recentEvents = events.filter((event) => parseISO(event.start) >= last30Start && parseISO(event.start) <= now);
  const trackableEvents = recentEvents.filter((event) => parseISO(event.start) <= now);
  const completed = trackableEvents.filter((event) => event.completed || parseISO(event.end) < now).length;
  const percentage = trackableEvents.length ? Math.round((completed / trackableEvents.length) * 100) : 0;
  const trainingEvents = recentEvents.filter((event) => event.category === 'Training' || event.category === 'WOD');
  const studyEvents = recentEvents.filter((event) => event.category === 'Study' || event.category === 'Class');
  const studyHours = studyEvents.reduce((sum, event) => sum + differenceInMinutes(parseISO(event.end), parseISO(event.start)), 0) / 60;
  const trainingStreak = calculateStreak(events, ['Training', 'WOD']);
  const studyStreak = calculateStreak(events, ['Study', 'Class']);
  const deadlines = events.filter((event) => /due|assignment|exam|deadline/i.test(event.title) && parseISO(event.end) > now).sort((a, b) => a.start.localeCompare(b.start));
  const activityDays = eachDayOfInterval({start: subDays(now, 69), end: now});
  const heatLevels = activityDays.map((day) => Math.min(4, events.filter((event) => isSameDay(parseISO(event.start), day) && (event.completed || parseISO(event.end) < now)).length));
  const weeklyBars = Array.from({length: 6}, (_, index) => {
    const end = subDays(now, (5 - index) * 7);
    const start = subDays(end, 6);
    return events.filter((event) => parseISO(event.start) >= start && parseISO(event.start) <= end).reduce((sum, event) => sum + differenceInMinutes(parseISO(event.end), parseISO(event.start)), 0) / 60;
  });
  const maxWeekly = Math.max(1, ...weeklyBars);
  const categoryMinutes = categories.map((category) => ({
    category,
    minutes: recentEvents.filter((event) => event.category === category).reduce((sum, event) => sum + differenceInMinutes(parseISO(event.end), parseISO(event.start)), 0),
  })).filter((item) => item.minutes > 0).sort((a, b) => b.minutes - a.minutes).slice(0, 5);
  const maxCategory = Math.max(1, ...categoryMinutes.map((item) => item.minutes));

  return (
    <Page onRefresh={reload}>
      <Header title="SIGNALS" action={<div className="feature-icon"><BarChart3 size={20} /></div>} />
      <section className="hero stats-hero premium-stats-hero">
        <div><span className="eyebrow">LAST 30 DAYS</span><h2>{trainingEvents.length + studyEvents.length} PERFORMANCE BLOCKS</h2><p>{studyHours.toFixed(1)} academic hours · {trainingEvents.length} training sessions · locally calculated.</p></div>
        <ProgressRing value={percentage} label="DONE" />
      </section>

      <div className="dashboard-grid stats-grid">
        <DashboardWidget icon={<Flame />} value={String(trainingStreak).padStart(2, '0')} label="Training streak" trend="consecutive active days" />
        <DashboardWidget icon={<BookOpen />} value={String(studyStreak).padStart(2, '0')} label="Study streak" trend="classes and focus work" />
        <DashboardWidget icon={<CheckCircle2 />} value={`${percentage}%`} label="Completion" trend={`${completed} completed blocks`} meter={percentage} />
        <DashboardWidget icon={<Award />} value={String(wods.length).padStart(2, '0')} label="WOD library" trend="saved sessions" />
      </div>

      <SectionTitle title="Six-week load" />
      <section className="trend-card">
        <div className="trend-head"><div><span>PLANNED HOURS</span><b>{weeklyBars.at(-1)?.toFixed(1) ?? '0.0'} THIS WEEK</b></div><TrendingUp size={20} /></div>
        <div className="trend-bars">{weeklyBars.map((value, index) => <div key={index}><i style={{height: `${Math.max(8, value / maxWeekly * 100)}%`}} /><span>W{index + 1}</span></div>)}</div>
      </section>

      <SectionTitle title="Activity matrix" />
      <div className="heatmap-card premium-heatmap">
        <div className="heatmap-head"><span>10 WEEKS · ACTUAL GRID DATA</span><span>LESS <i /><i /><i /><i /> MORE</span></div>
        <div className="heatmap">{heatLevels.map((level, index) => <i key={activityDays[index].toISOString()} data-level={level} title={`${format(activityDays[index], 'd MMM')}: ${level} completed blocks`} />)}</div>
      </div>

      <SectionTitle title="Time distribution" />
      <section className="category-breakdown">
        {categoryMinutes.length ? categoryMinutes.map((item) => (
          <div key={item.category}>
            <span><i style={{background: categoryColours[item.category]}} />{item.category}</span>
            <div><i style={{width: `${item.minutes / maxCategory * 100}%`, background: categoryColours[item.category]}} /></div>
            <b>{formatDuration(item.minutes)}</b>
          </div>
        )) : <EmptyState icon={<BarChart3 />} title="No activity yet" text="Completed schedule blocks will build your distribution automatically." />}
      </section>

      <div className="stats-split">
        <section>
          <SectionTitle title="Recent WODs" />
          <div className="mini-list">
            {wods.slice(-3).reverse().map((wod) => <NavLink to="/wod" key={wod.id}><span className="mini-list-icon"><Dumbbell /></span><div><b>{wod.name}</b><small>{wod.type} · {wod.movements.length} movements</small></div><ChevronRight /></NavLink>)}
            {!wods.length && <EmptyState icon={<Dumbbell />} title="No saved WODs" text="Build your first session and it will appear here." action="Open WOD Lab" to="/wod" />}
          </div>
        </section>
        <section>
          <SectionTitle title="Deadlines" />
          <div className="mini-list">
            {deadlines.slice(0, 3).map((event) => <NavLink to="/schedule" key={event.id}><span className="mini-list-icon warning"><TimerReset /></span><div><b>{event.title}</b><small>{format(parseISO(event.start), 'EEE d MMM')} · {formatTime(parseISO(event.start))}</small></div><ChevronRight /></NavLink>)}
            {!deadlines.length && <EmptyState icon={<Trophy />} title="No deadline flags" text="Grid found no upcoming titles containing exam, assignment, due or deadline." />}
          </div>
        </section>
      </div>
    </Page>
  );
}

function Settings({reload, onReplayOnboarding}: {reload: () => Promise<void>; onReplayOnboarding: () => void}) {
  const {notify} = useToast();
  const [preferences, setPreferences] = useState<GridPreferences>(() => readPreferences());
  const [dataSummary, setDataSummary] = useState({events: 0, wods: 0, notes: 0, usage: 'Local'});
  const standalone = window.matchMedia('(display-mode: standalone)').matches || Boolean((window.navigator as Navigator & {standalone?: boolean}).standalone);

  const refreshSummary = useCallback(async () => {
    const [eventCount, wodCount, noteCount] = await Promise.all([db.events.count(), db.wods.count(), db.notes.count()]);
    let usage = 'Local';
    if (navigator.storage?.estimate) {
      const estimate = await navigator.storage.estimate();
      if (estimate.usage) usage = estimate.usage < 1024 * 1024 ? `${Math.max(1, Math.round(estimate.usage / 1024))} KB` : `${(estimate.usage / 1024 / 1024).toFixed(1)} MB`;
    }
    setDataSummary({events: eventCount, wods: wodCount, notes: noteCount, usage});
  }, []);

  useEffect(() => { void refreshSummary(); }, [refreshSummary]);

  useEffect(() => {
    const media = window.matchMedia('(prefers-color-scheme: dark)');
    const update = () => {if (preferences.theme === 'system') applyPreferences(preferences);};
    media.addEventListener('change', update);
    return () => media.removeEventListener('change', update);
  }, [preferences]);

  const updatePreferences = <K extends keyof GridPreferences>(key: K, value: GridPreferences[K]) => {
    const next = {...preferences, [key]: value};
    if (key !== 'haptics' || value) haptic();
    setPreferences(next);
    persistPreferences(next);
  };

  const restore = async () => {
    await db.events.where('category').equals('Class').delete();
    await db.events.bulkPut(defaultClassEvents());
    await reload();
    await refreshSummary();
    notify('Default classes restored');
  };

  const reset = async () => {
    if (!window.confirm('Reset all Grid data on this device? This cannot be undone.')) return;
    await db.delete();
    window.location.reload();
  };

  const exportData = async () => {
    const data = {version: '1.2.0', exportedAt: new Date().toISOString(), events: await db.events.toArray(), wods: await db.wods.toArray(), notes: await db.notes.toArray()};
    const url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'}));
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `grid-backup-${format(new Date(), 'yyyy-MM-dd')}.json`;
    anchor.click();
    URL.revokeObjectURL(url);
    notify('Device-local backup exported');
  };

  const importData = (file: File) => {
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const data = JSON.parse(String(reader.result)) as {events?: GridEvent[]; wods?: Wod[]; notes?: DayNote[]};
        await db.transaction('rw', db.events, db.wods, db.notes, async () => {
          await Promise.all([db.events.clear(), db.wods.clear(), db.notes.clear()]);
          await db.events.bulkPut(data.events || []);
          await db.wods.bulkPut(data.wods || []);
          await db.notes.bulkPut(data.notes || []);
        });
        await reload();
        await refreshSummary();
        notify('Backup imported');
      } catch {
        notify('That backup could not be imported', 'warning');
      }
    };
    reader.readAsText(file);
  };

  return (
    <Page>
      <Header title="CONTROL" action={<div className="feature-icon"><SlidersHorizontal size={20} /></div>} />

      <section className="settings-status">
        <div className="settings-app-icon"><GridMark /></div>
        <div><span className="kicker">GRID 1.2</span><h2>Local-first system</h2><p>{standalone ? 'Installed app mode' : 'Browser mode'} · {dataSummary.usage} in use</p></div>
        <span className="system-good"><i />OPTIMAL</span>
      </section>

      <SectionTitle title="Appearance" />
      <div className="appearance-card premium-appearance">
        <div className="appearance-options">
          {([
            {value: 'dark' as ThemePreference, Icon: Moon, label: 'Dark'},
            {value: 'light' as ThemePreference, Icon: Sun, label: 'Light'},
            {value: 'system' as ThemePreference, Icon: Layers3, label: 'System'},
          ]).map(({value, Icon, label}) => (
            <button key={value} className={preferences.theme === value ? 'active' : ''} onClick={() => updatePreferences('theme', value)}>
              <span className="theme-preview"><i /><i /><i /></span><Icon size={18} /><span>{label}</span>{preferences.theme === value && <Check size={15} />}
            </button>
          ))}
        </div>
        <div className="accent-picker">
          <div><b>Signal colour</b><small>Applied to active controls, metrics and live states</small></div>
          <div>{accentOptions.map((option) => <button key={option.value} aria-label={option.name} className={preferences.accent === option.value ? 'active' : ''} style={{background: option.value}} onClick={() => updatePreferences('accent', option.value)}>{preferences.accent === option.value && <Check />}</button>)}</div>
        </div>
      </div>

      <SectionTitle title="Experience" />
      <div className="settings-list premium-settings-list">
        <SettingToggle icon={<Bell />} title="Haptic feedback" description="Tactile confirmation on supported devices" checked={preferences.haptics} onChange={(value) => updatePreferences('haptics', value)} />
        <SettingToggle icon={<Sparkles />} title="Reduced motion" description="Use calmer transitions throughout Grid" checked={preferences.reducedMotion} onChange={(value) => updatePreferences('reducedMotion', value)} />
        <button onClick={() => updatePreferences('timeFormat', preferences.timeFormat === '24' ? '12' : '24')}><Clock /><span>Time format<small>Switch between 12-hour and 24-hour display</small></span><b className="setting-value">{preferences.timeFormat}-HOUR</b></button>
        <button onClick={onReplayOnboarding}><Eye /><span>Replay onboarding<small>Review Grid’s product tour and controls</small></span><ChevronRight /></button>
      </div>

      <SectionTitle title="Local data" />
      <section className="data-vault">
        <div className="vault-head"><span className="vault-icon"><Database /></span><div><span>DEVICE VAULT</span><b>{dataSummary.events + dataSummary.wods + dataSummary.notes} local records</b></div><ShieldCheck /></div>
        <div className="vault-metrics"><span><b>{dataSummary.events}</b> events</span><span><b>{dataSummary.wods}</b> WODs</span><span><b>{dataSummary.notes}</b> notes</span></div>
        <p><Lock size={14} /> Grid does not send this data to a server.</p>
      </section>
      <div className="settings-list premium-settings-list">
        <button onClick={() => void restore()}><RotateCcw /><span>Restore classes<small>Reload the default university timetable</small></span><ChevronRight /></button>
        <button onClick={() => void exportData()}><Download /><span>Export JSON<small>Create a complete portable backup</small></span><ChevronRight /></button>
        <label className="settings-button"><Upload /><span>Import JSON<small>Restore an existing Grid backup</small></span><input hidden type="file" accept="application/json" onChange={(event) => event.target.files?.[0] && importData(event.target.files[0])} /><ChevronRight /></label>
        <button className="danger-row" onClick={() => void reset()}><Trash2 /><span>Reset data<small>Erase all local Grid data</small></span><ChevronRight /></button>
      </div>

      <SectionTitle title="Installation" />
      <section className={`install-card ${standalone ? 'installed' : ''}`}>
        <span className="install-icon"><Smartphone /></span>
        <div><span className="kicker">{standalone ? 'HOME SCREEN ACTIVE' : 'IPHONE INSTALL'}</span><h3>{standalone ? 'Grid is installed.' : 'Make Grid feel native.'}</h3><p>{standalone ? 'Standalone mode, safe areas and offline caching are active.' : 'Open in Safari, tap Share, then choose Add to Home Screen.'}</p></div>
        {standalone ? <CheckCircle2 /> : <ArrowUpRight />}
      </section>

      <article className="card about premium-about">
        <div className="about-mark"><GridMark /></div>
        <span className="eyebrow">ABOUT GRID</span>
        <h2>TRAIN. STUDY. PERFORM.</h2>
        <p>Version 1.2.0 · Premium Product Experience</p>
        <div className="about-rule" />
        <p>Designed as a private operating system for high-output students and functional fitness athletes.</p>
        <div className="about-badges"><span><WifiOff />Offline ready</span><span><ShieldCheck />Local first</span><span><Smartphone />PWA</span></div>
      </article>
    </Page>
  );
}

function SettingToggle({icon, title, description, checked, onChange}: {icon: React.ReactNode; title: string; description: string; checked: boolean; onChange: (value: boolean) => void}) {
  return (
    <button role="switch" aria-checked={checked} onClick={() => onChange(!checked)}>
      <span className="setting-leading">{icon}</span><span>{title}<small>{description}</small></span><i className={`switch ${checked ? 'on' : ''}`}><b /></i>
    </button>
  );
}

function Onboarding({onComplete}: {onComplete: () => void}) {
  const [step, setStep] = useState(0);
  const [accent, setAccent] = useState(readPreferences().accent);
  const reduceMotion = useReducedMotion();
  const slides = [
    {
      eyebrow: 'YOUR OPERATING SYSTEM',
      title: 'Own the next block.',
      text: 'Grid brings classes, study, training and daily intent into one fast command surface.',
      icon: <Gauge />,
      visual: <div className="onboarding-dashboard"><i /><i /><i /><i /></div>,
    },
    {
      eyebrow: 'TIME MEETS PERFORMANCE',
      title: 'Plan with context.',
      text: 'Move between schedule, WOD design and offline coaching without losing the shape of your day.',
      icon: <CalendarDays />,
      visual: <div className="onboarding-timeline"><span /><span /><span /></div>,
    },
    {
      eyebrow: 'PRIVATE BY DESIGN',
      title: 'Your data stays yours.',
      text: 'Grid stores schedules, workouts and notes locally, with offline access and portable JSON backups.',
      icon: <ShieldCheck />,
      visual: <div className="onboarding-vault"><Lock /><GridMark /></div>,
    },
  ];
  const slide = slides[step];

  const finish = () => {
    const preferences = {...readPreferences(), accent};
    persistPreferences(preferences);
    haptic(14);
    onComplete();
  };

  return (
    <motion.div className="onboarding-overlay" initial={{opacity: 0}} animate={{opacity: 1}} exit={{opacity: 0}} role="dialog" aria-modal="true" aria-label="Welcome to Grid">
      <div className="onboarding-shell">
        <header><span className="onboarding-wordmark"><GridMark />GRID</span><button onClick={finish}>Skip</button></header>
        <AnimatePresence mode="wait" initial={false}>
          <motion.section key={step} initial={reduceMotion ? false : {opacity: 0, x: 24}} animate={{opacity: 1, x: 0}} exit={reduceMotion ? undefined : {opacity: 0, x: -20}} transition={{duration: 0.28}}>
            <div className="onboarding-visual"><div className="onboarding-icon">{slide.icon}</div>{slide.visual}<span>0{step + 1}</span></div>
            <span className="kicker">{slide.eyebrow}</span>
            <h1>{slide.title}</h1>
            <p>{slide.text}</p>
            {step === 2 && (
              <div className="onboarding-accent">
                <span><Palette size={15} />Choose your signal</span>
                <div>{accentOptions.map((option) => <button key={option.value} aria-label={option.name} className={accent === option.value ? 'active' : ''} style={{background: option.value}} onClick={() => {setAccent(option.value); document.documentElement.style.setProperty('--accent', option.value);}}>{accent === option.value && <Check size={16} />}</button>)}</div>
              </div>
            )}
          </motion.section>
        </AnimatePresence>
        <footer>
          <div className="onboarding-dots">{slides.map((_, index) => <button key={index} className={index === step ? 'active' : ''} onClick={() => setStep(index)} aria-label={`Go to onboarding step ${index + 1}`} />)}</div>
          <button className="onboarding-next" onClick={() => step === slides.length - 1 ? finish() : setStep((current) => current + 1)}>{step === slides.length - 1 ? <><Smartphone />Enter Grid</> : <>Continue <ArrowRight /></>}</button>
        </footer>
      </div>
    </motion.div>
  );
}

function EmptyState({icon, title, text, action, to}: {icon: React.ReactNode; title: string; text: string; action?: string; to?: string}) {
  return (
    <div className="empty">
      <div className="empty-icon">{icon}</div>
      <h3>{title}</h3>
      <p>{text}</p>
      {action && to && <NavLink to={to}>{action}<ArrowRight size={15} /></NavLink>}
    </div>
  );
}

function Page({children, onRefresh}: {children: React.ReactNode; onRefresh?: () => Promise<void>}) {
  const reduceMotion = useReducedMotion();
  const pull = usePullToRefresh(onRefresh);
  return (
    <motion.div
      ref={pull.ref}
      className="page"
      initial={reduceMotion ? false : {opacity: 0, y: 10}}
      animate={{opacity: 1, y: pull.distance > 0 ? pull.distance * 0.28 : 0}}
      exit={reduceMotion ? undefined : {opacity: 0, y: -6}}
      transition={{duration: 0.22}}
    >
      {onRefresh && (
        <div className={`pull-indicator ${pull.armed ? 'armed' : ''} ${pull.refreshing ? 'refreshing' : ''}`} style={{transform: `translate(-50%, ${Math.max(-44, pull.distance - 54)}px)`, opacity: pull.distance ? 1 : 0}}>
          <RefreshCw size={17} /><span>{pull.refreshing ? 'Refreshing' : pull.armed ? 'Release to refresh' : 'Pull to refresh'}</span>
        </div>
      )}
      {children}
    </motion.div>
  );
}

function LaunchScreen() {
  return (
    <motion.div className="launch-screen" initial={{opacity: 0}} animate={{opacity: 1}} exit={{opacity: 0, scale: 1.02}} transition={{duration: 0.3}} aria-label="Launching Grid">
      <div className="launch-grid" />
      <motion.div className="launch-emblem" initial={{scale: 0.86, opacity: 0}} animate={{scale: 1, opacity: 1}} transition={{type: 'spring', damping: 20, stiffness: 220}}><GridMark /></motion.div>
      <motion.div className="launch-wordmark" initial={{opacity: 0, y: 8}} animate={{opacity: 1, y: 0}} transition={{delay: 0.12}}><b>GRID</b><span>TRAIN. STUDY. PERFORM.</span></motion.div>
      <div className="launch-progress"><i /></div>
      <small>LOCAL-FIRST PERFORMANCE SYSTEM</small>
    </motion.div>
  );
}

function formatCountdown(minutes: number) {
  if (minutes < 60) return `${Math.max(1, minutes)} min`;
  const hours = Math.floor(minutes / 60);
  const remaining = minutes % 60;
  return remaining ? `${hours}h ${remaining}m` : `${hours}h`;
}

function formatTime(date: Date) {
  return format(date, readPreferences().timeFormat === '12' ? 'h:mm a' : 'HH:mm');
}

function formatDuration(minutes: number) {
  if (minutes < 60) return `${Math.max(0, minutes)}m`;
  const hours = Math.floor(minutes / 60);
  const remainder = minutes % 60;
  return remainder ? `${hours}h ${remainder}m` : `${hours}h`;
}

function calculateStreak(events: GridEvent[], accepted: Category[]) {
  const activeDays = new Set(events.filter((event) => accepted.includes(event.category) && (event.completed || parseISO(event.end) < new Date())).map((event) => format(parseISO(event.start), 'yyyy-MM-dd')));
  let streak = 0;
  let cursor = new Date();
  if (!activeDays.has(format(cursor, 'yyyy-MM-dd'))) cursor = subDays(cursor, 1);
  while (activeDays.has(format(cursor, 'yyyy-MM-dd'))) {
    streak += 1;
    cursor = subDays(cursor, 1);
  }
  return streak;
}

export default App;
